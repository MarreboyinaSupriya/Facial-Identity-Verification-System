Smart Attendance system using Face Recognition in OpenCV
